# -*- coding: utf-8 -*-
"""
Created on Fri Dec  6 17:47:23 2024

@author: aaron
"""

import os

class Config:
    # Configuración de la base de datos
    SQLALCHEMY_DATABASE_URI = (
        "postgresql://postgres:jDAVozAeKtWdFXLgHZqZVLASPQSUGJLb@junction.proxy.rlwy.net:41649/railway"
    )

    SQLALCHEMY_TRACK_MODIFICATIONS = False



# postgresql://postgres:sdffahgdtruh@localhost:5432/gestion_ordenes

